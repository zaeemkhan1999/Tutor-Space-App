const admin = "SadiaSheikh"
const student = "MuhshamElahi"
const tutor = "ZaeemKhan"



module.exports = {admin, student, tutor}